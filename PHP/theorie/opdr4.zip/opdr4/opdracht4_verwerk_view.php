<!doctype html>
<html lang=nl>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bevestiging</title>

</head>
<body>
<h1>Bedankt voor het invullen van het formulier!</h1>
<p>
    Voornaam: <?= $naam ?><br>
    Achternaam: <?= $naam ?><br>
    Tussenvoegsel: <?= $naam ?><br>
    Uw e-mailadres is: <?= $email ?><br>
    Uw leeftijd is: <?= $leeftijd ?><br>
    Uw geboortedatum is: <?= $geboortedatum ?><br>
</p>
</body>
</html>